package com.bean;

public class Football_Hupu {

	private int hupu_id;
	private String hupu_title;
	private String hupu_data;
	private String hupu_area;
	private String hupu_url;
	
	public int getHupu_id() {
		return hupu_id;
	}
	public void setHupu_id(int hupu_id) {
		this.hupu_id = hupu_id;
	}
	public String getHupu_title() {
		return hupu_title;
	}
	public void setHupu_title(String hupu_title) {
		this.hupu_title = hupu_title;
	}
	public String getHupu_data() {
		return hupu_data;
	}
	public void setHupu_data(String hupu_data) {
		this.hupu_data = hupu_data;
	}
	public String getHupu_area() {
		return hupu_area;
	}
	public void setHupu_area(String hupu_area) {
		this.hupu_area = hupu_area;
	}
	public String getHupu_url() {
		return hupu_url;
	}
	public void setHupu_url(String hupu_url) {
		this.hupu_url = hupu_url;
	}
	
}
