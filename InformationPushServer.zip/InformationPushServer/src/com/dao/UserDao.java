package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.util.Util;

public class UserDao {

	private Util util;  
    private Connection conn;  
    private Statement st;  
    private ResultSet rs;
    
    public UserDao() throws Exception{  
        util = new Util();  
        conn = util.connectionDB(); 
        st = conn.createStatement();  
    }  
    
    
    public boolean select(String username, String password) throws SQLException {
    	
    	String sql = "select * from user where username = '"+username+"' and userpassword = '"+password+"'";
    	rs = st.executeQuery(sql);
    	if (rs.next()) {
			return true;
		}
		return false;
    }
    
    public boolean selectregister(String username) throws SQLException {
    	
    	String sql = "select * from user where username = '"+username+"'";
    	rs = st.executeQuery(sql);
    	if (rs.next()) {
			return true;
		}
		return false;
    }
    
    public void insert(String username, String hobby, String email, String password, String college) throws SQLException {
    	String sql = "insert into user(username,userhobby,useremail,userpassword,usercollege) values(?,?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(sql);// ����һ��Statement����
		ps.setString(1, username);
		ps.setString(2, hobby);
		ps.setString(3, email);
		ps.setString(4, password);
		ps.setString(5, college);
		
		
		System.out.println(sql);
		ps.executeUpdate();// ִ��sql���
    }
}
