package com.dao;

import java.sql.Connection;
import java.sql.Statement;
import java.util.Date;

import com.util.*;

public class NoticeDao {
	
	/*private Util util;  
    private Connection conn;  
    private Statement st;  
    
    public NoticeDao() throws Exception{  
        util=new Util();  
        conn=util.connectionDB(); 
        st=conn.createStatement();  
    }  */
    
    
  /*  //��֪ͨ����Ϣ�������ݿ�  
    public void insert(String title, String department, Date date, int frequency, String content, String img_url ) throws Exception{  
        String sql="INSERT INTO notice VALUES('"+title.replace("'", "")+"','"+department.replace("'", "")+"','"+date.replace("'", "")+"','"+frequency.replace("'", "")+"','"+content.replace("'", "")+"','"+introduce.replace("'", "")+"','"+img_url.replace("'", "")+"');";  
        System.out.println(sql);  
        st.executeUpdate(sql);  
    }
	*/

}
