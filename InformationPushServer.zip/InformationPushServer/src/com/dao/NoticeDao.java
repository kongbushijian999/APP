package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import com.util.*;

public class NoticeDao {
	
	private Util util;  
    private Connection conn;  
    private Statement st;  
    private ResultSet rs;
    
    public NoticeDao() throws Exception{  
        util = new Util();  
        conn = util.connectionDB(); 
        st = conn.createStatement();  
    }  
    
    
    
    public boolean check(String notice_title) throws SQLException {
    	
    	String sql = "select * from notice where notice_title = '"+notice_title+"'";
    	rs = st.executeQuery(sql);
    	if (rs.next()) {
			return true;
		}
		return false;
    }
    
    public void insert(String notice_title, String notice_time, String notice_url) throws SQLException {
    	String sql = "insert into notice(notice_title,notice_time,notice_url) values(?,?,?)";
		PreparedStatement ps = conn.prepareStatement(sql);// ����һ��Statement����
		ps.setString(1, notice_title);
		ps.setString(2, notice_time);
		ps.setString(3, notice_url);
		
		
		System.out.println(sql);
		ps.executeUpdate();// ִ��sql���
    }

}
