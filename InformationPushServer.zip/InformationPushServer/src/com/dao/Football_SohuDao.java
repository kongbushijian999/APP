package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.util.Util;

public class Football_SohuDao {

	private Util util;  
    private Connection conn;  
    private Statement st;  
    private ResultSet rs;
    
    public Football_SohuDao() throws Exception{  
        util = new Util();  
        conn = util.connectionDB(); 
        st = conn.createStatement();  
    }  
    
    
    
    public boolean check(String sohu_title) throws SQLException {
    	
    	String sql = "select * from football-sohu where sohu_title = '"+sohu_title+"'";
    	rs = st.executeQuery(sql);
    	if (rs.next()) {
			return true;
		}
		return false;
    }
    
    public void insert(String sohu_title, String sohu_url) throws SQLException {
    	String sql = "insert into football-sohu(sohu_title,sohu_url) values(?,?)";
		PreparedStatement ps = conn.prepareStatement(sql);// ����һ��Statement����
		ps.setString(1, sohu_title);
		ps.setString(2, sohu_url);
		
		System.out.println(sql);
		ps.executeUpdate();// ִ��sql���
    }
    
}
