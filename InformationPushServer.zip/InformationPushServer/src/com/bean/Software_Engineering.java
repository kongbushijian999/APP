package com.bean;

public class Software_Engineering {
	
	private int software_notice_id;
	private String software_notice_title;
	private String software_notice_detail;
	private String software_notice_time;
	private String software_notice_url;
	public int getSoftware_notice_id() {
		return software_notice_id;
	}
	public void setSoftware_notice_id(int software_notice_id) {
		this.software_notice_id = software_notice_id;
	}
	public String getSoftware_notice_title() {
		return software_notice_title;
	}
	public void setSoftware_notice_title(String software_notice_title) {
		this.software_notice_title = software_notice_title;
	}
	public String getSoftware_notice_detail() {
		return software_notice_detail;
	}
	public void setSoftware_notice_detail(String software_notice_detail) {
		this.software_notice_detail = software_notice_detail;
	}
	public String getSoftware_notice_time() {
		return software_notice_time;
	}
	public void setSoftware_notice_time(String software_notice_time) {
		this.software_notice_time = software_notice_time;
	}
	public String getSoftware_notice_url() {
		return software_notice_url;
	}
	public void setSoftware_notice_url(String software_notice_url) {
		this.software_notice_url = software_notice_url;
	}
	
	

}
