package com.bean;

public class Football_Menu {
	
	private int football_net_id;
	private String football_net_name;
	private String football_net_url;
	public int getFootball_net_id() {
		return football_net_id;
	}
	public void setFootball_net_id(int football_net_id) {
		this.football_net_id = football_net_id;
	}
	public String getFootball_net_name() {
		return football_net_name;
	}
	public void setFootball_net_name(String football_net_name) {
		this.football_net_name = football_net_name;
	}
	public String getFootball_net_url() {
		return football_net_url;
	}
	public void setFootball_net_url(String football_net_url) {
		this.football_net_url = football_net_url;
	}
	

}
