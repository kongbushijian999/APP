package com.bean;

public class Football_Sohu {
	
	private int sohu_id;
	private String sohu_title;
	private String sohu_url;
	public int getSohu_id() {
		return sohu_id;
	}
	public void setSohu_id(int sohu_id) {
		this.sohu_id = sohu_id;
	}
	public String getSohu_title() {
		return sohu_title;
	}
	public void setSohu_title(String sohu_title) {
		this.sohu_title = sohu_title;
	}
	public String getSohu_url() {
		return sohu_url;
	}
	public void setSohu_url(String sohu_url) {
		this.sohu_url = sohu_url;
	}

}
