package com.bean;

public class Mathematic_Engineering {
	private int mathematic_notice_id;
	private String mathematic_notice_title;
	private String mathematic_notice_time;
	private String mathematic_notice_url;
	public int getMathematic_notice_id() {
		return mathematic_notice_id;
	}
	public void setMathematic_notice_id(int mathematic_notice_id) {
		this.mathematic_notice_id = mathematic_notice_id;
	}
	public String getMathematic_notice_title() {
		return mathematic_notice_title;
	}
	public void setMathematic_notice_title(String mathematic_notice_title) {
		this.mathematic_notice_title = mathematic_notice_title;
	}
	public String getMathematic_notice_time() {
		return mathematic_notice_time;
	}
	public void setMathematic_notice_time(String mathematic_notice_time) {
		this.mathematic_notice_time = mathematic_notice_time;
	}
	public String getMathematic_notice_url() {
		return mathematic_notice_url;
	}
	public void setMathematic_notice_url(String mathematic_notice_url) {
		this.mathematic_notice_url = mathematic_notice_url;
	}
	
	

}
