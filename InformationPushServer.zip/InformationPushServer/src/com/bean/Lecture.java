package com.bean;

public class Lecture {
	
	private int lecture_id;
	private String lecture_title;
	private String lecture_time;
	private String lecture_url;
	public int getLecture_id() {
		return lecture_id;
	}
	public void setLecture_id(int lecture_id) {
		this.lecture_id = lecture_id;
	}
	public String getLecture_title() {
		return lecture_title;
	}
	public void setLecture_title(String lecture_title) {
		this.lecture_title = lecture_title;
	}
	public String getLecture_time() {
		return lecture_time;
	}
	public void setLecture_time(String lecture_time) {
		this.lecture_time = lecture_time;
	}
	public String getLecture_url() {
		return lecture_url;
	}
	public void setLecture_url(String lecture_url) {
		this.lecture_url = lecture_url;
	}

	
}
