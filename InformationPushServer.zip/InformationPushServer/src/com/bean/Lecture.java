package com.bean;

public class Lecture {
	
	private int lecture_id;
	private String lecture_title;
	private String lecture_time;
	private String lecture_location;
	private String lecturer;
	private String lecture_content;
	private String lecturer_introduction;
	private String lecture_video;


	public int getLecture_id() {
		return lecture_id;
	}
	public void setLecture_id(int lecture_id) {
		this.lecture_id = lecture_id;
	}
	public String getLecture_title() {
		return lecture_title;
	}
	public void setLecture_title(String lecture_title) {
		this.lecture_title = lecture_title;
	}
	public String getLecture_time() {
		return lecture_time;
	}
	public void setLecture_time(String lecture_time) {
		this.lecture_time = lecture_time;
	}
	public String getLecture_location() {
		return lecture_location;
	}
	public void setLecture_location(String lecture_location) {
		this.lecture_location = lecture_location;
	}
	public String getLecturer() {
		return lecturer;
	}
	public void setLecturer(String lecturer) {
		this.lecturer = lecturer;
	}
	public String getLecture_content() {
		return lecture_content;
	}
	public void setLecture_content(String lecture_content) {
		this.lecture_content = lecture_content;
	}
	public String getLecturer_introduction() {
		return lecturer_introduction;
	}
	public void setLecturer_introduction(String lecturer_introduction) {
		this.lecturer_introduction = lecturer_introduction;
	}
	public String getLecture_video() {
		return lecture_video;
	}
	public void setLecture_video(String lecture_video) {
		this.lecture_video = lecture_video;
	}
	
	
}
