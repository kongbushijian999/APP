package com.maintest;

import java.io.IOException;

import com.toserver.LoginToServer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class HobbyActivity extends Activity{
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO �Զ����ɵķ������
		super.onCreate(savedInstanceState);
		setContentView(R.layout.hobby);
		
		final EditText newneturl = (EditText)findViewById(R.id.newneturl);
		final EditText newnettitle = (EditText)findViewById(R.id.newnettitle);
		Button addnewnet = (Button)findViewById(R.id.addnewnet);
		
		addnewnet.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO �Զ����ɵķ������
				final Handler myHandler = new Handler(){  
                    public void handleMessage(Message msg){  
                        String responseResult = (String)msg.obj;  
                        //���ӳɹ�  
                        if(responseResult.equals("true")){  
                            Toast.makeText(HobbyActivity.this, "��¼�ɹ���", Toast.LENGTH_LONG).show(); 
                            Intent intent = new Intent(HobbyActivity.this, SecondActivity.class);
                            startActivity(intent);
                        }  
                        //����ʧ��  
                        else{  
                            Toast.makeText(HobbyActivity.this, "��¼ʧ�ܣ�", Toast.LENGTH_LONG).show();  
                        }  
                    }  
                };  
  
                new Thread(new Runnable() {  
                    @Override  
                    public void run() {  
                        LoginToServer loginToServer = new LoginToServer();  
                        try {  
                            String result = loginToServer.doPost(newneturl.getText().toString().trim(),newnettitle.getText().toString().trim());  
                            Message msg = new Message();  
                            msg.obj = result;  
                            myHandler.sendMessage(msg);  
  
                        } catch (IOException e) {  
                            e.printStackTrace();  
                        }  
                    }  
                }).start();  
			}
		});
	}

}
