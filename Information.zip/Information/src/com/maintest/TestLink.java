package com.maintest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import android.content.Entity;

public class TestLink {
	//����Tomcat�����������ڱ��أ�urlΪ����Tomcat�����url��IP��ַΪ��������IP��ַ  
    private String url = "http://115.154.62.90:8080/InformationPushServer/LoginServlet";  
    //���������صĽ��  
    String result = "";  
	public String doPost(String username, String password) throws IOException {  
        HttpClient httpClient = new DefaultHttpClient();  
        HttpPost httpPost = new HttpPost(url);  
        //��username��password����װ��List��  
        NameValuePair param1 = new BasicNameValuePair("username", username);  
        NameValuePair param2 = new BasicNameValuePair("password", password);  
        List<NameValuePair> params = new ArrayList<NameValuePair>();  
        params.add(param1);  
        params.add(param2);  
        //��������װ��HttpEntity�в�����HttpPost����������  
        HttpEntity httpEntity = new UrlEncodedFormEntity(params,HTTP.UTF_8);  
        httpPost.setEntity(httpEntity);  
        return "Error";  
     //   HttpResponse httpResponse = httpClient.execute(httpPost); 
     
        //�����Ӧ�ɹ�  
//        if(httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK){  
//            //�õ���Ϣ��  
//            result=EntityUtils.toString(httpResponse.getEntity(),"utf-8");
//            return result;
//        }  
//        //��Ӧʧ��  
//        else{  
//            return "Error";  
//        }  
    }  
}
