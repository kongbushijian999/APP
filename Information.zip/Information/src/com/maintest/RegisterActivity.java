package com.maintest;

import java.io.IOException;

import com.toserver.RegisterToServer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class RegisterActivity extends Activity {
	protected static final int ERROR = 1;
	protected static final int SUCCESS = 2;

	private EditText reusername;
	private EditText reemail;
	private EditText repassword;
	private EditText repasswordtwo;
	private Spinner recollege;
	private Spinner rehobby;
	private Button register;

	private String stcollege;
	private String sthobby;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO �Զ����ɵķ������
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register);

		reusername = (EditText) findViewById(R.id.reusername);
		reemail = (EditText) findViewById(R.id.reemail);
		repassword = (EditText) findViewById(R.id.repassword);
		repasswordtwo = (EditText) findViewById(R.id.repasswordtwo);

		recollege = (Spinner) findViewById(R.id.recollege);
		rehobby = (Spinner) findViewById(R.id.rehobby);
		register = (Button) findViewById(R.id.register);

		recollege.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO �Զ����ɵķ������

			}

			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
				// TODO �Զ����ɵķ������
				String result = parent.getItemAtPosition(position).toString();
				stcollege = result.trim();
			}
		});

		rehobby.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO �Զ����ɵķ������
				
			}

			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
				// TODO �Զ����ɵķ������
				String result = parent.getItemAtPosition(position).toString();
				sthobby = result.trim();
			}
		});

		register.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				final String stusername = reusername.getText().toString().trim();
				final String stemail = reemail.getText().toString().trim();
				final String stpassword = repassword.getText().toString().trim();
				final String stpasswordtwo = repasswordtwo.getText().toString().trim();

				if (TextUtils.isEmpty(stusername)) {
					Toast.makeText(RegisterActivity.this, "�û�������Ϊ��", Toast.LENGTH_SHORT).show();
				}
				if (TextUtils.isEmpty(stemail)) {
					Toast.makeText(RegisterActivity.this, "���䲻��Ϊ��", Toast.LENGTH_SHORT).show();
				}
				if (TextUtils.isEmpty(stpassword)) {
					Toast.makeText(RegisterActivity.this, "���벻��Ϊ��", Toast.LENGTH_SHORT).show();
				}
				if (TextUtils.isEmpty(stpasswordtwo)) {
					Toast.makeText(RegisterActivity.this, "ȷ�����벻��Ϊ��", Toast.LENGTH_SHORT).show();
				}
				if (!stpassword.equals(stpasswordtwo)) {
					Toast.makeText(RegisterActivity.this, "��������Ҫһ��", Toast.LENGTH_SHORT).show();
				}

				final Handler myHandler = new Handler() {
					public void handleMessage(Message msg) {
						String responseResult = (String) msg.obj;
						// ע��ɹ�
						if (responseResult.equals("true")) {
							Toast.makeText(RegisterActivity.this, "ע��ɹ���", Toast.LENGTH_LONG).show();
							Intent intent = new Intent(RegisterActivity.this, SecondActivity.class);
							startActivity(intent);
						}
						// ע��ʧ��
						else {
							Toast.makeText(RegisterActivity.this, "ע��ʧ�ܣ�", Toast.LENGTH_LONG).show();
						}
					}
				};

				new Thread(new Runnable() {
					@Override
					public void run() {
						RegisterToServer registerToServer = new RegisterToServer();
						try {
							String result = registerToServer.doPost(stusername, sthobby, stemail, stpassword,
									stpasswordtwo, stcollege);
							Message msg = new Message();
							msg.obj = result;
							myHandler.sendMessage(msg);

						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}).start();

			}
		});

	}

	// �����ж�
	/*
	 * public void normalchecked() { final String
	 * reusername=reusername.getText().toString().trim();
	 * 
	 * }
	 * 
	 * if (reusername == null) { Toast.makeText(RegisterActivity.this, "�û�������Ϊ��",
	 * Toast.LENGTH_SHORT).show(); } if (reemail == null) {
	 * Toast.makeText(RegisterActivity.this, "���䲻��Ϊ��", Toast.LENGTH_SHORT).show(); }
	 * if (rehobby == null) { Toast.makeText(RegisterActivity.this, "���ò���Ϊ��",
	 * Toast.LENGTH_SHORT).show(); } if (repassword == null) {
	 * Toast.makeText(RegisterActivity.this, "���벻��Ϊ��", Toast.LENGTH_SHORT).show(); }
	 * if (repasswordtwo ==null) { Toast.makeText(RegisterActivity.this, "ȷ�����벻��Ϊ��",
	 * Toast.LENGTH_SHORT).show(); }
	 */

}
